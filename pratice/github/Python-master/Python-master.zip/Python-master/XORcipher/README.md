
### XORCipher class

This class implements the XOR-cipher algorithm and provides some useful methods for encrypting and decrypting strings and
files. You will find detailed docstrings in each method.

#### Overview about methods

* encrypt : list of char
* decrypt : list of char
* encrypt_string : str
* decrypt_string : str
* encrypt_file : boolean
* decrypt_file : boolean